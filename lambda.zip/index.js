const AWS = require('aws-sdk');
const dynamoDB = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
    const cpf = event.pathParameters.cpf;
    const params = {
        TableName: 'Users',
        Key: { cpf: cpf }
    };

    try {
        const data = await dynamoDB.get(params).promise();
        if (data.Item) {
            return {
                statusCode: 200,
                body: JSON.stringify({ exists: true, user: data.Item }),
            };
        } else {
            return { statusCode: 404, body: JSON.stringify({ exists: false }) };
        }
    } catch (error) {
        return { statusCode: 500, body: JSON.stringify({ error: 'Erro ao consultar no Banco.', details: error.message }) };
    }
};
